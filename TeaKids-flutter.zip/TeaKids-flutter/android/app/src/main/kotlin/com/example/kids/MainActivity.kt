package com.example.kids

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

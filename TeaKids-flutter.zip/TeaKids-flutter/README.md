#  __TEA KIDS__
Projeto em desenvolvimento, para formação do Curso de ADS da FATEC de Ribeirão Preto/SP.

<h3> Objetivo </h3>
Temos como objetivo desenvolver um aplicativo que contenha jogos (jogo da memória, completar formas ou figuras) e atividades interativas, voltadas para crianças com TEA (Transtorno do Espectro Autista).
Nâo temos a itenção de transformar em um aplicativo que trás diagnóstico, ou que seja educativo.
O objetivo é trazer um aplicativo para lazer.
A ideia está crua ainda em relação a desenvolvimento.

<h2>Telas do aplicativo </h2>

<h3> Login </h3>
- <a href= "https://github.com/alifi3988/TeaKids/blob/flutter/lib/view/login.dart"> Código; </a>

<h3> Tela de cadastro </h3>
- <a href= "https://github.com/alifi3988/TeaKids/blob/flutter/lib/view/cadastro.dart"> Código; </a>

<h3>  Recuperar a senha </h3>
- <a href= "https://github.com/alifi3988/TeaKids/blob/flutter/lib/view/recuperar.dart"> Código; </a>

<h3> Menu </h3>
- <a href= "https://github.com/alifi3988/TeaKids/blob/flutter/lib/view/principal.dart"> Código; </a>

<h3> Jogo da memória </h3>
- <a href= "https://github.com/alifi3988/TeaKids/blob/flutter/lib/view/memoria.dart"> Código; </a>

<h3> Jogo das cores </h3>
- <a href= "https://github.com/alifi3988/TeaKids/blob/flutter/lib/view/cores.dart"> Código; </a>

<h3> Jogo de Raciocínio </h3>
- <a href= "https://github.com/alifi3988/TeaKids/blob/flutter/lib/view/raciocinio.dart> Código; </a>

<h3> Figura de animais </h3>
- <a href= "https://github.com/alifi3988/TeaKids/blob/flutter/lib/view/animais.dart"> Código; </a>

<h3> Relatório </h3>
- <a href= "https://github.com/alifi3988/TeaKids/blob/flutter/lib/view/relatorio.dart"> Código; </a>

<h3> Sobre </h3>
- <a href= "https://github.com/alifi3988/TeaKids/blob/flutter/lib/view/sobre.dart"> Código; </a>




